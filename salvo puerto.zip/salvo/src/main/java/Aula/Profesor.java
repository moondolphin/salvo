package Aula;

public class Profesor extends Persona{


    protected String materia;


    public Profesor() {
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }
}
