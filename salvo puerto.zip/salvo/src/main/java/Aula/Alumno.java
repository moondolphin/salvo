package Aula;

public class Alumno extends Persona {
    //variables
    protected int cantMat;

    //constructor
    public Alumno() {
    }

    //getters y setters
    public int getCantMat() {
        return cantMat;
    }

    public void setCantMat(int cantMat) {
        this.cantMat = cantMat;
    }
}
